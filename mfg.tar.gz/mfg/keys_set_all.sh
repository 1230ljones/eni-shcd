#!/bin/bash
#sets all keys. Pass in option "-e" to set keys for external switches (Columbias) as well.
rm /root/.ssh/known_hosts
cbios --AdminAdd -n `cnodes --cmc | xargs | sed -e 's/ /,/g'`;sleep 5
cbios --ConsoleAdd -n `cnodes --cmc | xargs | sed -e 's/ /,/g'`;sleep 5
cbios --AdminAdd -n `cnodes --node-controller | xargs | sed -e 's/ /,/g'`;sleep 5
cbios --ConsoleAdd -n `cnodes --node-controller | xargs | sed -e 's/ /,/g'`;sleep 5
cbios --AdminAdd -n `cnodes --switch-controller | xargs | sed -e 's/ /,/g'`
if [[ $1 == "-e" ]];then
	sleep 10
	cbios --AdminAdd -n `cnodes --external-switch-controller | xargs | sed -e 's/ /,/g'`;sleep 5
	cbios --ConsoleAdd -n `cnodes --external-switch-controller | xargs | sed -e 's/ /,/g'`;sleep 5
fi
